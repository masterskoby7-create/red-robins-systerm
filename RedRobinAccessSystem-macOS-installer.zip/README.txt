Red Robin Access System - macOS Installer Package
This zip contains the macOS installer script for the app.
Run install.command from the downloaded folder or execute it via Terminal.
