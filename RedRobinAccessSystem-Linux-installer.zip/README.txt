Red Robin Access System - Linux Installer Package
This zip contains the Linux installer script for the app.
Run install.sh from the downloaded folder to create the local installation.
