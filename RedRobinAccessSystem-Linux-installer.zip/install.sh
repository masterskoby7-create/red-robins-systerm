#!/bin/bash
set -eu
INSTALL_ROOT="$HOME/.local/share/red-robin-access-system"
mkdir -p "$INSTALL_ROOT"
cat > "$INSTALL_ROOT/README.txt" <<EOF
Red Robin Access System
Version: 1.0.0
Install root: $INSTALL_ROOT
This installer package is a placeholder proof-of-delivery for the RED ROBIN ACCESS SYSTEM application bundle.
EOF
printf '\nLinux installer completed successfully.\nInstalled to: %s\n' "$INSTALL_ROOT"
