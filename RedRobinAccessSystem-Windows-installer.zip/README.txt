Red Robin Access System - Windows Installer Package

1. Extract the entire ZIP file.
2. Double-click Install.bat.
3. Open the desktop shortcut named "Red Robin Access System".

You can also open the app from Command Prompt. After installation, run:

start "" "%LOCALAPPDATA%\RedRobin\AccessSystem\index.html"

Or double-click Open App.bat in the installation folder:
%LOCALAPPDATA%\RedRobin\AccessSystem

The app runs in your web browser and saves its account and settings data in that
browser on this computer. Its network, Bluetooth, and drive lists are sample data;
it does not access or monitor real devices.
