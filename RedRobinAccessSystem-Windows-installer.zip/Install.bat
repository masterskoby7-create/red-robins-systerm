@echo off
setlocal
title Red Robin Access System Installer

echo Installing Red Robin Access System...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Please contact support.
  pause
  exit /b 1
)

echo.
echo Installation finished.
pause
