$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSource = Join-Path $packageRoot 'app'
$installRoot = Join-Path $env:LOCALAPPDATA 'RedRobin\AccessSystem'
$desktopPath = Join-Path $env:USERPROFILE 'Desktop\Red Robin Access System.lnk'

$requiredFiles = @('index.html', 'app.js', 'styles.css', 'Open App.bat')
$missingFiles = $requiredFiles | Where-Object { -not (Test-Path (Join-Path $appSource $_) -PathType Leaf) }
if ($missingFiles) {
  throw "The installer is missing application files: $($missingFiles -join ', '). Extract the entire ZIP and run Install.bat again."
}

New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
Copy-Item -Path (Join-Path $appSource '*') -Destination $installRoot -Recurse -Force

$WshShell = New-Object -ComObject WScript.Shell
$shortcut = $WshShell.CreateShortcut($desktopPath)
$shortcut.TargetPath = Join-Path $installRoot 'index.html'
$shortcut.Save()

Write-Host 'Red Robin Access System installed successfully.'
Write-Host 'Open it using the desktop shortcut or double-click Open App.bat in the install folder.'
Write-Host ''
Write-Host 'To open it from Command Prompt, run:'
Write-Host 'start "" "%LOCALAPPDATA%\RedRobin\AccessSystem\index.html"'
Write-Host ''
Write-Host "Install folder: $installRoot"
